#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "util_asysbang.h"

void log(const char* info) {
	fprintf(stderr, "===>>>");
	fprintf(stderr, info);
	fprintf(stderr, "\n");
}


int getRandom(int max){
	srand((unsigned)time(NULL));
	return rand() % max;
}

bool inRgb(RGB rgb, int r, int g, int b, int deta) {
	if (r - deta < rgb.r && rgb.r < r + deta && g - deta < rgb.g && rgb.g < g + deta && b - deta < rgb.b && rgb.b < b + deta) {
		return true;
	}
	return false;
}

bool inRgb(RGB rgb, int r, int g, int b) {
	return inRgb(rgb, r, g, b, 3);
}

RGB getRgb(void const* base, int x, int y) {
	RGB rgb;
	char const* values = (char *) base + y * WIDTH * BYTESPP + x * BYTESPP;
	rgb.r = values[0];
	rgb.g = values[1];
	rgb.b = values[2];
//	fprintf(stderr, "=======x=%d,y=%d==%d=%d=%d=\n", x, y, rgb.r, rgb.g, rgb.b);
	return rgb;
}

//计算平均值，不包含x1,y1点
RGB getAvgRgb(void const* base, int x0, int y0, int x1, int y1) {
	RGB rgb;
	int red = 0;
	int green = 0;
	int blue = 0;
	int count = (x1 - x0) * (y1 - y0);
	for (int x = x0; x < x1; x++) {
		for (int y = y0; y < y1; y++) {
			char const* values = (char *) base + y * WIDTH * BYTESPP + x * BYTESPP;
			red = red + values[0];
			green = green + values[1];
			blue = blue + values[2];
		}
	}
	rgb.r = red / count;
	rgb.g = green / count;
	rgb.b = blue / count;
	//fprintf(stderr, "=======avg==%d=%d=%d=\n", rgb.r, rgb.g, rgb.b);
	return rgb;
}

//注意deta是不包含的
bool isTarget(void const* base, int x0, int y0, int x1, int y1, int r, int g, int b, int rdeta, int gdeta, int bdeta,
		int percent) {
	int target = 0;
	int count = (x1 - x0) * (y1 - y0);
	for (int x = x0; x < x1; x++) {
		for (int y = y0; y < y1; y++) {
			char const* values = (char *) base + y * WIDTH * BYTESPP + x * BYTESPP;
			if (r - rdeta < values[0] && values[0] < r + rdeta) {
				if (g - gdeta < values[1] && values[1] < g + gdeta) {
					if (b - bdeta < values[2] && values[2] < b + bdeta) {
						target++;
					}
				}
			}
		}
	}
	int res = target * 100 / count;
	fprintf(stderr, "=======isTarget==%d==\n", res);
	return res >= percent;

}
