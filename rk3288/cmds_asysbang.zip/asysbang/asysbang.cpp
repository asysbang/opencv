#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/time.h> 
#include <time.h> 

#include <binder/ProcessState.h>

#include <gui/SurfaceComposerClient.h>
#include <gui/ISurfaceComposer.h>

#include <ui/PixelFormat.h>

#include <SkImageEncoder.h>
#include <SkBitmap.h>
#include <SkData.h>
#include <SkStream.h>
#include "event_asysbang.h"
#include "util_asysbang.h"
#include "hearthstone.h"
#include "mhxy.h"
using namespace android;

void testLongTime() {
	int i = 0;
	void const* base = 0;
	int32_t displayId = ISurfaceComposer::eDisplayIdMain;
	ScreenshotClient screenshot;
	sp < IBinder > display = SurfaceComposerClient::getBuiltInDisplay(displayId);
	while (i < 100000) {
		fprintf(stderr, "=========i=%d=\n", i);
		if (screenshot.update(display, Rect(), false) == NO_ERROR) {
			fprintf(stderr, "=========screenshot.getPixels\n");
			base = screenshot.getPixels();
		}
		if (base) {
			fprintf(stderr, "=========testLongTime=base\n");
		} else {
			fprintf(stderr, "=========xxxxxxxxxxxxxxxxxxxxxxxxxxxx=base\n");
			sleep(1);
			continue;
		}
		RGB rgb = getAvgRgb(base, 100, 100, 110, 103);
		if (rgb.r == 150 && rgb.g == 39 && rgb.b == 11) {
			down(340, 300);
			move(320, 300);
			move(300, 300);
			move(280, 300);
			move(260, 300);
			move(260, 280);
			move(260, 260);
			move(260, 240);
			up();
//			sleep(2);
			down(760, 1840);
			up();
		} else if (rgb.r == 245 && rgb.g == 245 && rgb.b == 245) {
			down(888, 2008);
			up();
		}
		base = 0;
		//screenshot.release();
		//SurfaceComposerClient::destroyDisplay(display);
		sleep(1);
		i++;
	}
}

static SkColorType flinger2skia(PixelFormat f) {
	switch (f) {
	case PIXEL_FORMAT_RGB_565:
		return kRGB_565_SkColorType;
	default:
		return kN32_SkColorType;
	}
}
void screencap() {
	fprintf(stderr, "=========screencap\n");
	struct timeval t;
	gettimeofday(&t, NULL);
	//fprintf(stderr, "===t.tv_sec = %ld=== \n", t.tv_sec);
	char file[25];
	sprintf(file, "/data/pp/%ld.png", t.tv_sec);
	fprintf(stderr, "%s\n", file);
	int fd = -1;
	fd = open(file, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	void const* base = 0;
	uint32_t w, s, h, f;
	size_t size = 0;
	int32_t displayId = ISurfaceComposer::eDisplayIdMain;
	ScreenshotClient screenshot;
	sp < IBinder > display = SurfaceComposerClient::getBuiltInDisplay(displayId);
	if (display != NULL && screenshot.update(display, Rect(), false) == NO_ERROR) {
		base = screenshot.getPixels();
		w = screenshot.getWidth();
		h = screenshot.getHeight();
		s = screenshot.getStride();
		f = screenshot.getFormat();
		size = screenshot.getSize();
		fprintf(stderr, "=========%d , %d\n",w,h);
	}

	const SkImageInfo info = SkImageInfo::Make(w, h, flinger2skia(f), kPremul_SkAlphaType);
	SkBitmap b;
	b.installPixels(info, const_cast<void*>(base), s * bytesPerPixel(f));
	SkDynamicMemoryWStream stream;
	SkImageEncoder::EncodeStream(&stream, b, SkImageEncoder::kPNG_Type, SkImageEncoder::kDefaultQuality);
	SkData* streamData = stream.copyToData();
	write(fd, streamData->data(), streamData->size());
	streamData->unref();
	return;
}

/**
 * 没有参数：长时间测试
 * p：截图，默认/data/pp/time.png
 * hs:hearthstone
 * 
 */

int main(int argc, char** argv) {
	if (argc == 1) {
		testLongTime();
		return 0;
	} else
	if (strcmp(argv[1], "p") == 0) {
		screencap();
	} else if (strcmp(argv[1], "hs") == 0) {
		hearthstone();
	} else if (strcmp(argv[1], "mh") == 0) {
		mhxy();
	} else {
		fprintf(stderr, "===>>>错误参数\n");
	}

	return 0;
}
