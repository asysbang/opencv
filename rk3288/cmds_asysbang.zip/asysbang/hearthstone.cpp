#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/time.h> 
#include <time.h> 

#include <binder/ProcessState.h>

#include <gui/SurfaceComposerClient.h>
#include <gui/ISurfaceComposer.h>

#include <ui/PixelFormat.h>

#include <SkImageEncoder.h>
#include <SkBitmap.h>
#include <SkData.h>
#include <SkStream.h>
#include "event_asysbang.h"
#include "util_asysbang.h"
#include "hearthstone.h"
using namespace android;

/**
 * 代码结构
 * 	常用：战斗
 * 	非常用：等级奖励、卡牌奖励
 *	场景（左上物体）：飞艇、火箭
 *
 *
 *
 */

void hearthstone() {
	log("开始启动");
	int i = 0;
	void const* base = 0;
	int32_t displayId = ISurfaceComposer::eDisplayIdMain;
	ScreenshotClient screenshot;
	sp < IBinder > display = SurfaceComposerClient::getBuiltInDisplay(displayId);
	while (i < 100000) {
		RGB rgb;
		if (screenshot.update(display, Rect(), false) == NO_ERROR) {
			base = screenshot.getPixels();
		}
		//火箭[40,217,6]   紫色液体[34,174,5]  恐龙[36,193,5]  绿色人在3个人中间 [37,199,5]
		//绿头红宝石眼睛[37,192,5]  舞台大箱子紫烟[36,194,5]
		rgb = getAvgRgb(base, 850, 1860, 860, 1890);
		if (20 < rgb.r && rgb.r < 55 && 155 < rgb.g && rgb.g < 230 && 0 < rgb.b && rgb.b < 20) {
			log("对战界面-回合结束-等待5秒");
//			fprintf(stderr, "===>>> 对战界面-回合结束-等待5秒=\n");
			tap(860, 1900);
			sleep(5);
			continue;
		}
		//[123,245,255]
		rgb = getAvgRgb(base, 330, 1620, 340, 1650);
		if (inRgb(rgb, 123, 245, 255)) {
			log("对战界面-点击开始-等待5秒");
			tap(280, 1650);
			sleep(5);
			continue;
		}

		//[95,84,74]
		rgb = getAvgRgb(base, 690, 300, 850, 320);
		if (inRgb(rgb, 95, 84, 74)) {
			log("搜寻对手-等待5秒");
			sleep(5);
			continue;
		}

		//[103,120,212][110,128,221][114,133,224]
		rgb = getAvgRgb(base, 370, 650, 380, 700);
		if (100 < rgb.r && rgb.r < 117 && 117 < rgb.g && rgb.g < 136 && 209 < rgb.b && rgb.b < 227) {
			log("战斗结束胜利-等待5秒");
			tap(1060, 960);
			sleep(5);
			continue;
		}

		//这个是飘动的，所以只能找“点击继续”这4个汉字
		rgb = getAvgRgb(base, 67, 1052, 102, 1054);
		if (inRgb(rgb, 254, 254, 254, 5)) {
			rgb = getAvgRgb(base, 67, 990, 106, 991);
			if (inRgb(rgb, 254, 254, 254, 5)) {
				log("点击继续-等待5秒");
				tap(1060, 960);
				sleep(5);
				continue;
			}
		}

		//[78,68,49][78,68,49]
		rgb = getAvgRgb(base, 1430, 810, 1440, 870);
		if (74 < rgb.r && rgb.r < 82 && 64 < rgb.g && rgb.g < 72 && 45 < rgb.b && rgb.b < 54) {
			log("任务完成-等待3秒");
			tap(1060, 960);
			sleep(3);
			continue;
		}

		//[94,103,178]
		rgb = getAvgRgb(base, 375, 620, 400, 630);
		if (90 < rgb.r && rgb.r < 98 && 109 < rgb.g && rgb.g < 107 && 174 < rgb.b && rgb.b < 182) {
			log("奖励提示-等待3秒");
			tap(1060, 960);
			sleep(3);
			continue;
		}
		//[172,127,69]
		rgb = getAvgRgb(base, 1210, 1160, 1230, 1220);
		if (170 < rgb.r && rgb.r < 174 && 125 < rgb.g && rgb.g < 129 && 67 < rgb.b && rgb.b < 71) {
			log("今日任务-等待3秒");
			tap(1060, 960);
			sleep(3);
			continue;
		}
		//[35,20,17][36,20,18]
		rgb = getAvgRgb(base, 980, 260, 1020, 270);
		if (inRgb(rgb, 36, 20, 18, 5)) {
			log("首页面");
			//判断对战模式的汉字  81 60 31
			rgb = getRgb(base, 1074, 983);
			if (78 < rgb.r && rgb.r < 84 && 57 < rgb.g && rgb.g < 63 && 28 < rgb.b && rgb.b < 34) {
				log("首页面-点击对战-等待3秒");
				tap(1060, 960);
				sleep(3);
				continue;
			}
			sleep(5);
			continue;
		}
		base = 0;
		sleep(5);
		i++;
	}

}
