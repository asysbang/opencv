#include <png.h>
#include <stdio.h>
int main() {
	int width, height;
	png_structp png_ptr;
	png_infop info_ptr;
	FILE *fp;
	if ((fp = fopen("/mnt/sdcard/e.png", "r")) == NULL)
		return 0;
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);     //1.初始化libpng
	info_ptr = png_create_info_struct(png_ptr);    //2.创建图像信息
	fprintf(stderr, "=========>>>>>> start\n");
	png_init_io(png_ptr, fp);                       //4.设置libpng的数据源
	png_read_png(png_ptr, info_ptr, PNG_TRANSFORM_EXPAND, 0);     // 5. png图像处理
	width = png_get_image_width(png_ptr, info_ptr);
	height = png_get_image_height(png_ptr, info_ptr);
	fprintf(stderr, "=========>>>>>> width = %d , height = %d \n", width, height);

	char* rgba = new char[width * height * 4];
	png_bytep* row_pointers = png_get_rows(png_ptr, info_ptr);    //6. 得到文件的宽高色深
	int pos = 0;
	int threshold = 0;
	for (int row = 0; row < width; row++) {
		for (int col = 0; col < (4 * height); col += 4) {
//			fprintf(stderr, "=========>>>>>>[%d, %d] [%d,%d,%d] \n", col / 4, row, row_pointers[row][col],
//					row_pointers[row][col + 1], row_pointers[row][col + 2]);

			/**
			int tem = 0.11 *row_pointers[row][col] + 0.59*row_pointers[row][col + 1] + 0.3*row_pointers[row][col + 2];
			threshold += tem;
			row_pointers[row][col] = tem;
			row_pointers[row][col + 1] = tem;
			row_pointers[row][col + 2] = tem;
			row_pointers[row][col + 3] = 255;
*/
			//**最小值
			 int tem = row_pointers[row][col];
			 if (tem > row_pointers[row][col + 1]) {
			 tem = row_pointers[row][col + 1];
			 }
			 if (tem > row_pointers[row][col + 2]) {
			 tem = row_pointers[row][col + 2];
			 }
			 threshold +=tem;
			 row_pointers[row][col]=tem;
			 row_pointers[row][col+1]=tem;
			 row_pointers[row][col+2]=tem;
			 row_pointers[row][col+3]=255;
			// */
			/**3分之一
			 int tem = row_pointers[row][col] + row_pointers[row][col+1]+ row_pointers[row][col+2];
			 threshold +=tem/3;
			 row_pointers[row][col]=tem/3;
			 row_pointers[row][col+1]=tem/3;
			 row_pointers[row][col+2]=tem/3;
			 row_pointers[row][col+3]=255;
			 */
			pos += 4;
		}
	}
	threshold = threshold/ (width * height);
	fprintf(stderr, "=======threshold=%d",threshold);
	threshold = 230;
	for (int row = 0; row < width; row++) {
		for (int col = 0; col < (4 * height); col += 4) {
			int tem = 0;
			if (row_pointers[row][col] > threshold) {
				tem = 255;
			}
			row_pointers[row][col] = tem;
			row_pointers[row][col + 1] = tem;
			row_pointers[row][col + 2] = tem;
			row_pointers[row][col + 3] = 255;
			pos += 4;
		}
	}

	//写入
	FILE *fout;
	if ((fout = fopen("/mnt/sdcard/out.png", "wb")) == NULL)
		return 0;

	png_structp write_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	//png_infop write_info_ptr = png_create_info_struct(write_ptr);
	png_init_io(write_ptr, fout);
	png_write_png(write_ptr, info_ptr, PNG_TRANSFORM_IDENTITY, NULL);

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);                //7. 释放libpng的内存
	fclose(fp);
	fclose(fout);
	return 0;
}
