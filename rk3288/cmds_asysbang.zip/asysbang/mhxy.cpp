#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <time.h>
#include <binder/ProcessState.h>
#include <gui/SurfaceComposerClient.h>
#include <gui/ISurfaceComposer.h>
#include <ui/PixelFormat.h>
#include <SkImageEncoder.h>
#include <SkBitmap.h>
#include <SkData.h>
#include <SkStream.h>
#include "event_asysbang.h"
#include "util_asysbang.h"
#include "mhxy.h"
using namespace android;

//0 - 进入游戏初始界面
//1 - 准备接受任务
int state = 0;
void mhxy() {
	log("开始启动");
	int i = 0;
	void const* base = 0;
	int32_t displayId = ISurfaceComposer::eDisplayIdMain;
	ScreenshotClient screenshot;
	sp < IBinder > display = SurfaceComposerClient::getBuiltInDisplay(displayId);
	while (i < 100000) {
		RGB rgb;
		if (screenshot.update(display, Rect(), false) == NO_ERROR) {
			base = screenshot.getPixels();
		}

		/**   进入游戏初始界面 0  可以做的判断*/

		if (state == 0) {
			//判断“为了提升您的游戏体验”
			if (isTarget(base, 377, 64, 379, 96, 235, 235, 235, 21, 21, 21, 88)) {
				log("为了提升您的游戏体验1");
				tap(380, 1980, 30, 30);
				sleep(getRandom(2)+1);
				continue;
			}
			//判断“聊天框的大小”
			rgb = getAvgRgb(base, 575, 40, 585, 90);
			if (rgb.r == 150 && rgb.g == 39 && rgb.b == 11) {

			}
		} else
		/** 准备接受任务状态1 可以做的判断*/
		if (state == 1) {

		}


		//道具行囊-使用飞行旗
		if (isTarget(base, 1271, 896, 1274, 920, 235, 235, 235, 21, 21, 21, 88)) {
			log("道具行囊界面");
			tap(565, 1565, 80, 80);
			sleep(3);
			log("使用飞行旗");
			tap(683, 673, 40, 70);
			sleep(3);
			continue;
		}
		//1199, 1655, 1233, 1658, 235, 235, 235, 21, 21, 21, 88
		//点击到酒馆门口
		if (isTarget(base, 1199, 1655, 1233, 1658, 235, 235, 235, 21, 21, 21, 88)) {
			log("点击到酒馆门口");
			tap(844, 1505, 40, 40);
			sleep(3);
			continue;
		}
		//打开道具
		rgb = getAvgRgb(base, 160, 1770, 200, 1800);
		if (state == 0 && inRgb(rgb, 219, 120, 45)) {
			log("打开道具");
			state = 1;
			tap(150, 1760, 50, 50);
			sleep(3);
			continue;
		}
		base = 0;
		sleep(5);
		i++;
	}
}
