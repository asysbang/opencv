#include "event_asysbang.h"
#include <stdio.h>
#include <linux/input.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <dirent.h>

#include "util_asysbang.h"

#define EVENT_FD "/dev/input/event0"

#define EVENT_TIME 20000

#define EVENT_DOWN   0
#define EVENT_UP   1
#define EVENT_MOVE   2
static int touchEventFd = -1;
static int touchEvent_mt_type = 0;
static int X_MIN = 0;
static int X_MAX = 768;
static int Y_MIN = 0;
static int Y_MAX = 1024;

static void calculateXYForEvent(float x, float y, int *event_x, int *event_y) {
	*event_x = X_MIN + (int) ((x * (float) (X_MAX - X_MIN)) / WIDTH + 0.5);
	*event_y = Y_MIN + (int) ((y * (float) (Y_MAX - Y_MIN)) / HEIGHT + 0.5);
}

static void write_event_to_fd(int fd, int type, int code, int value) {
	struct input_event event;
	memset(&event, 0, sizeof(event));
	event.type = type;
	event.code = code;
	event.value = value;
	write(fd, &event, sizeof(event));
}

int event_touch(int action, float x, float y) {
	int event_x, event_y;
	switch (action) {
	case EVENT_DOWN:
		calculateXYForEvent(x, y, &event_x, &event_y);
		write_event_to_fd(touchEventFd, 3, 57, 1);
		write_event_to_fd(touchEventFd, 3, 53, event_x);
		write_event_to_fd(touchEventFd, 3, 54, event_y);
		write_event_to_fd(touchEventFd, 0, 0, 0);
		break;
	case EVENT_UP:
		write_event_to_fd(touchEventFd, 3, 57, -1);
		write_event_to_fd(touchEventFd, 0, 0, 0);
		break;
	case EVENT_MOVE:
		calculateXYForEvent(x, y, &event_x, &event_y);
		write_event_to_fd(touchEventFd, 3, 53, event_x);
		write_event_to_fd(touchEventFd, 3, 54, event_y);
		write_event_to_fd(touchEventFd, 0, 0, 0);
		usleep(EVENT_TIME);
		break;
	}
	return 0;
}

void check() {
	if (touchEventFd < 0) {
		touchEventFd = open(EVENT_FD, O_RDWR | O_CLOEXEC);
	}
}

void down(int x, int y) {
	check();
	event_touch(EVENT_DOWN, x, y);
	usleep(EVENT_TIME * 4);
}
void move(int x, int y) {
	event_touch(EVENT_MOVE, x, y);
	usleep(EVENT_TIME * 4);

}
void up() {
	event_touch(EVENT_UP, 0, 0);
}

void tap(int x, int y) {
	down(x, y);
	up();
}

void tap(int x, int y, int xDeta, int yDeta) {
	down(x + getRandom(xDeta), y + getRandom(yDeta));
	up();
}
