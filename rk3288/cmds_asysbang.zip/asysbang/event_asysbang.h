/**
 * http://www.asysbang.com
 * 
 * 点击事件处理类
 * 
 * 向 /dev/input/event0 发送 input_event 
 * 提供down  move  up事件
 * 
 */

void down(int x, int y);
void move(int x, int y);
void up();
void tap(int x, int y);
//点击对应的坐标，同时随机偏移
void tap(int x, int y, int xDeta, int yDeta);
