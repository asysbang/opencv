/**
 * http://www.asysbang.com
 * 
 * mhxy类
 * 
 * 处理mhxy的逻辑
 * 
 */

void mhxy();