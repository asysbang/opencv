#include <png.h>
#include <stdio.h>
#include<stdlib.h>
#include "util_asysbang.h"
#include <unistd.h>
int main() {

	//测试用到的参数
	png_uint_32 width, height; //宽度，高度
	int bit_depth, color_type; //位深，颜色类型
	int interlace_type, compression_type, filter_type; //扫描方式，压缩方式，滤波方式

	fprintf(stderr, "=========>>>>>> crop png\n");
	//png_structp 和png_infop  是每个png对应的结构体和信息
	png_structp in_png_ptr, out_png_ptr;
	png_infop in_info_ptr, out_info_ptr;

	//初始化结构体
	in_png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	out_png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

	//初始化信息
	in_info_ptr = png_create_info_struct(in_png_ptr);
	out_info_ptr = png_create_info_struct(out_png_ptr);

	//打开对应文件
	FILE *in_fp, *out_fp;
	if ((in_fp = fopen("/mnt/sdcard/5.png", "r")) == NULL) {
		fprintf(stderr, "=========>>>>>> 打开原始文件失败\n");
		return 0;
	}
	//关联文件流和对应的结构体
	png_init_io(in_png_ptr, in_fp);

	if ((out_fp = fopen("/mnt/sdcard/d.png", "wb")) == NULL) {
		fprintf(stderr, "=========>>>>>> 打开要生成文件失败\n");
		return 0;
	}
	//关联文件流和对应的结构体
	png_init_io(out_png_ptr, out_fp);

	//读取原始png信息
	png_read_png(in_png_ptr, in_info_ptr, PNG_TRANSFORM_EXPAND, 0);
//	width = png_get_image_width(in_png_ptr, in_info_ptr);
//	height = png_get_image_height(in_png_ptr, in_info_ptr);
//	fprintf(stderr, "=========>>>>>> width = %d , height = %d \n", width, height);
	png_get_IHDR(in_png_ptr, in_info_ptr, &width, &height, &bit_depth, &color_type, &interlace_type, &compression_type,
			&filter_type);
	fprintf(stderr, "=========>>>>>> width = %d , height = %d \n", width, height);
	fprintf(stderr, "=========>>>>>> bit_depth = %d , color_type = %d \n", bit_depth, color_type);
	fprintf(stderr, "=========>>>>>> interlace_type = %d , compression_type = %d ,filter_type = %d\n", interlace_type,
			compression_type, filter_type);
	//设置目标文件信息

	fprintf(stderr, "=========>>>>>> PNG_COLOR_TYPE_RGBA = %d , PNG_INTERLACE_NONE = %d \n", PNG_COLOR_TYPE_RGBA,
	PNG_INTERLACE_NONE);
	fprintf(stderr, "=========>>>>>> PNG_COMPRESSION_TYPE_BASE = %d , PNG_FILTER_TYPE_BASE = %d \n", PNG_COMPRESSION_TYPE_BASE,
	PNG_FILTER_TYPE_BASE);
	png_set_IHDR(out_png_ptr, out_info_ptr, 40, 40, //尺寸
			bit_depth, //颜色深度，也就是每个颜色成分占用位数（8表示8位红8位绿8位蓝，如果有透明通道则还会有8位不透明度）
			PNG_COLOR_TYPE_RGBA, //颜色类型，PNG_COLOR_TYPE_RGB表示24位真彩深色，PNG_COLOR_TYPE_RGBA表示32位带透明通道真彩色
			PNG_INTERLACE_NONE, //不交错。PNG_INTERLACE_ADAM7表示这个PNG文件是交错格式。交错格式的PNG文件在网络传输的时候能以最快速度显示出图像的大致样子。
			PNG_COMPRESSION_TYPE_BASE, //压缩方式
			PNG_FILTER_TYPE_BASE); //这个不知道，总之填写PNG_FILTER_TYPE_BASE即可。
	png_set_packing(out_png_ptr); //设置打包信息
	png_write_info(out_png_ptr, out_info_ptr); //写入文件头

	//写入数据
	png_bytep row = NULL;
	png_bytep* row_pointers = png_get_rows(in_png_ptr, in_info_ptr);
	fprintf(stderr, "========%d -------\n", row_pointers[60][350 * 4]);
	for (int y = 0; y < 40; y++) {
		row = (png_bytep) malloc(bit_depth * 40 * sizeof(png_byte));
		for (int x = 0; x < 40 * 4; x += 4) {
			int tem = getRandom(10);
			sleep(3);
			fprintf(stderr, "======getRandom==%d -------\n", tem);
			/** 完全copy
			 //对应原图的位置是 [350,60]
			 row[x] = row_pointers[61 + y][351 * 4 + x];
			 row[x + 1] = row_pointers[61 + y][351 * 4 + x + 1];
			 row[x + 2] = row_pointers[61 + y][351 * 4 + x + 2];
			 row[x + 3] = 255;
			 */

			//按照自己需求的颜色值进行二值处理
			//对应原图的位置是 [350,60]
			//第一层参数  rgb 颜色值来判断黑白的数值  当前 210
			if (row_pointers[61 + y][351 * 4 + x] > 210 && row_pointers[61 + y][351 * 4 + x + 1] > 210
					&& row_pointers[61 + y][351 * 4 + x + 2] > 210) {
				row[x] = 255;
				row[x + 1] = 255;
				row[x + 2] = 255;
			} else {
				row[x] = 0;
				row[x + 1] = 0;
				row[x + 2] = 0;
			}
			row[x + 3] = 255;
		}
		png_write_row(out_png_ptr, row);
	}

	//创建8×8的数据矩阵
	for (int y = 0; y < 8; y++) {
		for (int x = 0; x < 8; x++) {
			//按照自己需求的颜色值进行二值处理
			//对应原图的位置是 [350,60]
			//第一层参数  rgb 颜色值来判断黑白的数值  当前 210
			int left = 350 + x * 5;
			int right = 350 + x * 5 + 5;
			int top = 60 + y * 5;
			int bottom = 60 + y * 5 + 5;
//			fprintf(stderr, "======left = %d , right = %d ,top = %d, bottom = %d--\n", left, right, top, bottom);
		}
	}

	//收尾
//	png_read_end(in_png_ptr,in_info_ptr);
	png_destroy_read_struct(&in_png_ptr, &in_info_ptr, NULL);
	fclose(in_fp);

	fprintf(stderr, "=========>>>>>> -------\n");
	png_write_end(out_png_ptr, out_info_ptr);
	fprintf(stderr, "=========>>>>>> ----1111---\n");
	png_destroy_write_struct(&out_png_ptr, &out_info_ptr);
	fclose(out_fp);
	return 0;
}
