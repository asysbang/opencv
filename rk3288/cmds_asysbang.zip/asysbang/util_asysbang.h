#define BYTESPP 4
#define WIDTH 1536
#define HEIGHT 2048

struct RGB {
	char r;
	char g;
	char b;
};

//生成随机数
int getRandom(int max);
//控制台输出log信息
void log(const char* info);
//判断rgb值是否在某个区间内，默认deta = 3
bool inRgb(RGB rgb, int r, int g, int b);
//判断rgb值是否在某个区间内，deta可以设置
bool inRgb(RGB rgb, int r, int g, int b, int deta);
//获取某点的rgb值
RGB getRgb(void const* base, int x, int y);
//获取某区域的rgb平均值
RGB getAvgRgb(void const* base, int x0, int y0, int x1, int y1);
//获取某区域的rgb平均值
bool isTarget(void const* base, int x0, int y0, int x1, int y1, int r, int g, int b, int rdeta, int gdeta, int bdeta,
		int percent);
