/**
 * http://www.asysbang.com
 * 
 * hearthstone类
 * 
 * 处理hearthstone的逻辑
 * 
 */

void hearthstone();